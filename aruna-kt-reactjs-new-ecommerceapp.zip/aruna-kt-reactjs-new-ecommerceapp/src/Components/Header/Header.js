import { NavLink } from "react-router-dom";
import ImageLogo from './Images/logoimg-3.png'
import ImageCart from './Images/cart.webp'

import image1 from './Images/image1.webp';
import image2 from './Images/image2.webp';
import image3 from './Images/image3.webp';
import image4 from './Images/image4.webp';
import image5 from './Images/image5.webp';
import image6 from './Images/image6.webp';
import image7 from './Images/image7.webp';
import image8 from './Images/image8.webp';
import image9 from './Images/image9.webp';
import image10 from './Images/image10.webp';






const Header = ({cartItems,searchTextCB}) => {

    function searchText($event){
        searchTextCB($event.target.value);
     }

    return ( 
        <div className="position-sticky top-0 start-0 end-0 z-3">
            <nav className="navbar navbar-expand-lg bg-danger bg-gradient">
                <div className="container-fluid">
                    <img className="navbar-brand " src={ImageLogo} style={{height:'80px'}} />
                    <button className="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                        <span className="navbar-toggler-icon"></span>
                    </button>
                    <div className="collapse navbar-collapse" id="navbarSupportedContent">
                        <ul className="navbar-nav me-auto mb-2 mb-lg-0">
                            <li className="nav-item me-2">
                                <NavLink to={'/'} className="nav-link fw-bold">Home</NavLink>
                            </li>
                            <li className="nav-item">
                                <NavLink to={'/ProductsPage'} className="nav-link me-2 fw-bold">Products</NavLink>
                            </li>
                            <li className="nav-item">
                                <NavLink to={'/contact'} className="nav-link fw-bold">Contact Us</NavLink>
                            </li>
                            <li className="nav-item">
                                <NavLink to={'/about'} className="nav-link me-2 fw-bold" >About Us</NavLink>
                            </li>
                            
                            <a href="#" className="nav-item fs-5" style={{textDecoration:'none'}}>
                                <NavLink to={'/cart'}><img src={ImageCart} height={25}/></NavLink>
                                {
                                    cartItems.length === 0 ? '' :
                                    <span className="bg-success rounded-circle mt-5 cart-icon">
                                        {
                                            cartItems.length === 0 ? '' : cartItems.length
                                        }
                                    </span>
                                }
                            </a>
                           
                            <li className="nav-item">
                                <NavLink to={'/login'} className="nav-link fw-bold">Login</NavLink>
                            </li>
                           
                        </ul>
                        <form className="d-flex" role="search">
                            <input className="form-control me-2" type="search" placeholder="Search" aria-label="Search" onInput={searchText}/>
                            <button className="btn btn-outline-success me-2" type="submit">Search</button>
                        </form>
                    </div>
                </div>
            </nav>

            <nav className="navbar navbar-expand-lg bg-danger bg-gradient">
      <div className="container-fluid">
        <a className="navbar-brand  fw-bold" href="/">Popular products</a>
        <button className="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
          <span className="navbar-toggler-icon"></span>
        </button>
        <div className="collapse navbar-collapse" id="navbarNav">
          <ul className="navbar-nav ms-auto">
            <li className="nav-item">
              <a className="nav-link" href="#">
                <img src={image1} style={{height:'70px'}} alt="icon1" className="nav-icon" />
              </a>
            </li>
            <li className="nav-item">
              <a className="nav-link" href="#">
                <img src={image2} style={{height:'70px'}} alt="icon2" className="nav-icon" />
              </a>
            </li>
            <li className="nav-item">
              <a className="nav-link" href="#">
                <img src={image3} style={{height:'70px'}} alt="icon3" className="nav-icon" />
              </a>
            </li>
            <li className="nav-item">
              <a className="nav-link" href="#">
                <img src={image4} style={{height:'70px'}} alt="icon4" className="nav-icon" />
              </a>
            </li>
            <li className="nav-item">
              <a className="nav-link" href="#">
                <img src={image5} style={{height:'70px'}} alt="icon5" className="nav-icon" />
              </a>
            </li>
            <li className="nav-item">
              <a className="nav-link" href="#">
                <img src={image6} style={{height:'70px'}} alt="icon1" className="nav-icon" />
              </a>
            </li>
            <li className="nav-item">
              <a className="nav-link" href="#">
                <img src={image7} style={{height:'70px'}} alt="icon2" className="nav-icon" />
              </a>
            </li>
            <li className="nav-item">
              <a className="nav-link" href="#">
                <img src={image8} style={{height:'70px'}} alt="icon3" className="nav-icon" />
              </a>
            </li>
            <li className="nav-item">
              <a className="nav-link" href="#">
                <img src={image9} style={{height:'70px'}} alt="icon4" className="nav-icon" />
              </a>
            </li>
            <li className="nav-item">
              <a className="nav-link" href="#">
                <img src={image10} style={{height:'70px'}} alt="icon5" className="nav-icon" />
              </a>
            </li>
          </ul>
        </div>
      </div>
    </nav>

        </div>
       
        
     );
}
 
export default Header;