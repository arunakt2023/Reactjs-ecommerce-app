const About = () => {
    return ( 
        <div className="container mt-5 mb-5">
            <div className="row">
                <div className="col d-flex flex-column justify-content-center">
                    <h1>About Us</h1>
                    <p className="fw-normal">Welcome to Ecommerce , where shopping meets convenience and quality. At Ecommerce , we're dedicated to providing you with a seamless online shopping experience. Whether you're looking for the latest fashion trends, electronics, home essentials, or gifts for your loved ones, we've got you covered..</p>
                    <p className="fw-normal">Backed by a team of passionate professionals, we're committed to excellence in customer service and product satisfaction. Your trust is our top priority, and we continuously work towards enhancing our platform to exceed your expectations.</p>
                    <p className="fw-semibold">Join us on this journey of innovation and convenience. Shop with confidence at Ecommerce, your go-to destination for all your shopping needs.
                        Experience the difference today.
</p>
                    <img src="https://img.freepik.com/free-vector/shop-with-sign-we-are-open_23-2148546273.jpg?w=740&t=st=1715510283~exp=1715510883~hmac=81db76c4b6e7fa54732f4327f9c71437f6f3ff96ba97331eeee65a8a7678d598" style={{height:'300px'}}  alt=""/>
                </div>
            </div>    
        </div>
     );
}
 
export default About;